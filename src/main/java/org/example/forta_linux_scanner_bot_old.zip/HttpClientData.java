public class HttpClientData {
    String address;
    String name;

    public HttpClientData(String address, String name){
        this.address = address;
        this.name = name;
    }
}
